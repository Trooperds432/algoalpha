"""Trusted policy, bounded I/O and fail-closed lifecycle tests (no hostile host source)."""

from __future__ import annotations

import hashlib
import json
import sys
import threading
from dataclasses import replace
from pathlib import Path

import pytest

from quant_terminal.sandbox.podman import (
    PodmanBackend,
    PodmanCapability,
    PodmanConfig,
    SandboxUnavailable,
    cleanup_command,
    command_for,
    read_container_id,
)
from quant_terminal.sandbox.protocol import SandboxBudget

IMAGE = "sha256:" + "a" * 64
BUDGET = SandboxBudget(10, 5, 64_000_000, 4, 32, 0, 0, 2048)


def config(tmp_path: Path) -> PodmanConfig:
    return PodmanConfig(
        IMAGE, "/home/user/algoalpha-seccomp.json", audit_path=tmp_path / "audit.jsonl"
    )


def blob(dependencies: dict[str, str] | None = None) -> bytes:
    source = "def on_bar(context, bar): return []"
    return json.dumps(
        {
            "version": 1,
            "job_id": "job-1",
            "source": source,
            "source_sha256": hashlib.sha256(source.encode()).hexdigest(),
            "data_rows": [{"close": "100"}],
            "data_sha256": hashlib.sha256(b'[{"close":"100"}]').hexdigest(),
            "dependencies": dependencies or {},
            "seed": 1,
            "budget": {key: getattr(BUDGET, key) for key in BUDGET.__dataclass_fields__},
        }
    ).encode()


def test_rejects_mutable_image_and_windows_profile(tmp_path: Path) -> None:
    with pytest.raises(ValueError, match="digest-pinned"):
        PodmanConfig("python:3.13", "/profile.json")
    with pytest.raises(ValueError, match="absolute Linux"):
        PodmanConfig(IMAGE, "C:\\Users\\profile.json")
    with pytest.raises(ValueError, match="absolute Linux"):
        PodmanConfig(IMAGE, "/vm/../profile.json")
    with pytest.raises(ValueError, match="absolute"):
        PodmanConfig(IMAGE, "/profile", audit_path=Path("relative"))
    with pytest.raises(ValueError, match="distribution"):
        PodmanConfig(IMAGE, "/profile", wsl_distribution="--help")


def test_command_enforces_confinement_and_no_host_mounts(tmp_path: Path) -> None:
    command = command_for(config(tmp_path), BUDGET, tmp_path / "job.cid", "job-1")
    for flag in (
        "--network=none",
        "--read-only",
        "--read-only-tmpfs=false",
        "--cap-drop=ALL",
        "--security-opt=no-new-privileges",
        "--user=65532:65532",
        "--userns=auto",
        "--ipc=none",
        "--pid=private",
        "--uts=private",
        "--cgroupns=private",
        "--pids-limit=4",
        "--memory=64000000",
        "--memory-swap=64000000",
        "--cpus=0.5000",
        "--ulimit=cpu=5:5",
        "--ulimit=nofile=32:32",
        "--ulimit=fsize=2048:2048",
        "--timeout=10",
        "--log-driver=none",
        "--http-proxy=false",
        "--restart=no",
        "--pull=never",
    ):
        assert flag in command
    assert all(
        not x.startswith(("--volume", "--publish", "--privileged", "--device=")) for x in command
    )
    assert not any(x.startswith("--tmpfs") for x in command)
    assert command[-4:] == (IMAGE, "-I", "-S", "/opt/algoalpha/strategy_worker.py")


def test_unenforceable_limits_and_ids_reject(tmp_path: Path) -> None:
    for budget in (
        replace(BUDGET, scratch_bytes=1),
        replace(BUDGET, scratch_files=1),
        replace(BUDGET, cpu_seconds=11),
        replace(BUDGET, wall_seconds=3600),
    ):
        with pytest.raises(SandboxUnavailable):
            command_for(config(tmp_path), budget, tmp_path / "cid", "job")
    with pytest.raises(ValueError, match="job ID"):
        command_for(config(tmp_path), BUDGET, tmp_path / "cid", "../secret")
    with pytest.raises(ValueError, match="absolute"):
        command_for(config(tmp_path), BUDGET, Path("relative"), "job")
    rounded = command_for(
        config(tmp_path), replace(BUDGET, wall_seconds=7, cpu_seconds=3), tmp_path / "cid", "job"
    )
    assert "--cpus=0.4285" in rounded  # never round a total CPU budget upwards


def test_container_id_and_label_guarded_cleanup(tmp_path: Path) -> None:
    cidfile = tmp_path / "cid"
    cidfile.write_text("../other")
    assert read_container_id(cidfile) is None
    cidfile.write_text("f" * 64)
    assert read_container_id(cidfile) == "f" * 64
    assert "--filter=label=algoalpha.owner=quant-terminal-m16" in cleanup_command("f" * 64)
    assert f"--filter=id=^{'f' * 64}$" in cleanup_command("f" * 64)
    with pytest.raises(ValueError):
        cleanup_command("--all")


def test_audit_required_before_any_engine_operation(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    backend = PodmanBackend(PodmanConfig(IMAGE, "/profile"))
    monkeypatch.setattr(backend, "probe", lambda: pytest.fail("no runtime without audit"))
    with pytest.raises(SandboxUnavailable, match="audit_unavailable"):
        backend.execute(blob())
    backend = PodmanBackend(replace(config(tmp_path), audit_path=tmp_path))
    with pytest.raises(SandboxUnavailable, match="audit_write_failed"):
        backend.execute(blob())


def test_dependencies_reject_before_source_launch(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    backend = PodmanBackend(config(tmp_path))
    monkeypatch.setattr(
        backend, "probe", lambda: pytest.fail("unsupported dependency before probe")
    )
    with pytest.raises(SandboxUnavailable, match="dependencies_unsupported"):
        backend.execute(blob({"package==1.0": "b" * 64}))
    events = [json.loads(line) for line in (tmp_path / "audit.jsonl").read_text().splitlines()]
    assert [event["event"] for event in events] == ["admission", "rejection"]
    assert all("source" not in event for event in events)
    assert events[0]["source_sha256"]


def test_cleanup_failure_stays_closed_across_instances(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    backend = PodmanBackend(config(tmp_path))

    def fail(*args: object, **kwargs: object) -> bytes:
        raise SandboxUnavailable("podman_command_failed")

    monkeypatch.setattr(backend, "_run", fail)
    with pytest.raises(SandboxUnavailable, match="container_cleanup_failed"):
        backend._cleanup("f" * 64)
    other = PodmanBackend(config(tmp_path))
    assert other.probe().reason == "cleanup_unhealthy"
    assert (tmp_path / "audit.unhealthy").exists()


def test_successful_reconciliation_clears_latch(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    backend = PodmanBackend(config(tmp_path))
    backend._mark_unhealthy()
    monkeypatch.setattr(backend, "_run", lambda *args, **kwargs: b"")
    assert backend.reconcile() == 0
    assert not backend._is_unhealthy()
    assert not (tmp_path / "audit.unhealthy").exists()


def test_bounded_output_and_cancellation_use_harmless_process(tmp_path: Path) -> None:
    backend = PodmanBackend(config(tmp_path))
    with pytest.raises(SandboxUnavailable, match="output_limit"):
        backend._stream((sys.executable, "-c", "print('x'*8192)"), b"", 1024, 2, None)
    event = threading.Event()
    event.set()
    with pytest.raises(SandboxUnavailable, match="cancelled"):
        backend._stream((sys.executable, "-c", "import time;time.sleep(0.5)"), b"", 1024, 2, event)


def test_unverified_identity_and_capability_reject(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    backend = PodmanBackend(config(tmp_path))
    monkeypatch.setattr(backend, "probe", lambda: PodmanCapability(False, "engine_unavailable"))
    with pytest.raises(SandboxUnavailable, match="engine_unavailable"):
        backend.identity()
    with pytest.raises(SandboxUnavailable, match="engine_unavailable"):
        backend.execute(blob())


def test_client_environment_excludes_secret_values(monkeypatch: pytest.MonkeyPatch) -> None:
    from quant_terminal.sandbox.podman import _client_environment

    monkeypatch.setenv("TRADING212_SECRET", "broker-secret-sentinel")
    monkeypatch.setenv("OPENROUTER_API_KEY", "model-secret-sentinel")
    monkeypatch.setenv("PAPERCLIP_API_KEY", "agent-secret-sentinel")
    monkeypatch.setenv("USERPROFILE", "C:/Users/Example")
    env = _client_environment()
    assert env["USERPROFILE"] == "C:/Users/Example"
    assert not any("secret-sentinel" in value for value in env.values())


def test_preset_cancel_never_probes_or_launches(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    backend = PodmanBackend(config(tmp_path))
    event = threading.Event()
    event.set()
    monkeypatch.setattr(backend, "probe", lambda: pytest.fail("already cancelled"))
    with pytest.raises(SandboxUnavailable, match="cancelled"):
        backend.execute(blob(), cancel=event)
    events = [json.loads(line) for line in (tmp_path / "audit.jsonl").read_text().splitlines()]
    assert [entry["event"] for entry in events] == ["admission", "rejection"]
    assert events[-1]["outcome"] == "cancelled"


def test_watchdog_acquires_current_parent_identity_then_stops(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    from quant_terminal.sandbox.protocol import decode_request

    backend = PodmanBackend(config(tmp_path))
    monkeypatch.setattr(backend, "_executable", lambda: sys.executable)
    lease = backend._begin_lease()
    watcher = backend._watchdog("f" * 64, decode_request(blob()), lease)
    assert watcher.poll() is None
    backend._stop_watchdog(watcher)
    assert watcher.poll() is not None
    events = [json.loads(line) for line in (tmp_path / "audit.jsonl").read_text().splitlines()]
    assert events[0]["event"] == "watchdog_ready"
    assert events[0]["reason"] == "retained_parent_handle"
    lease.unlink()


def test_health_write_failure_preserves_durable_pending_lease(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    import quant_terminal.sandbox.podman as module

    monkeypatch.setattr(module, "_ACTIVE_LEASES", set())
    monkeypatch.setattr(module, "_PROCESS_UNHEALTHY", set())
    backend = PodmanBackend(config(tmp_path))
    lease = backend._begin_lease()
    original = Path.open

    def deny_health(path: Path, *args: object, **kwargs: object):
        if path.suffix == ".unhealthy":
            raise OSError("storage unavailable")
        return original(path, *args, **kwargs)

    monkeypatch.setattr(Path, "open", deny_health)
    with pytest.raises(SandboxUnavailable, match="health_write_failed"):
        backend._mark_unhealthy()
    assert PodmanBackend(config(tmp_path)).probe().reason == "cleanup_unhealthy"
    # Simulate a fresh scheduler process which has no registered live leases.
    module._ACTIVE_LEASES.clear()
    module._PROCESS_UNHEALTHY.clear()
    assert lease.exists()
    assert PodmanBackend(config(tmp_path)).probe().reason == "cleanup_unhealthy"


def test_health_preflight_failure_prevents_container_create(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    backend = PodmanBackend(config(tmp_path))
    monkeypatch.setattr(backend, "probe", lambda: PodmanCapability(True, "controls_verified"))
    monkeypatch.setattr(
        backend, "_create", lambda *args: pytest.fail("no create without durable health")
    )
    original = Path.open

    def deny_pending(path: Path, *args: object, **kwargs: object):
        if path.suffix == ".pending":
            raise OSError("storage unavailable")
        return original(path, *args, **kwargs)

    monkeypatch.setattr(Path, "open", deny_pending)
    with pytest.raises(SandboxUnavailable, match="health_preflight_failed"):
        backend.execute(blob())


def test_premature_watchdog_exit_fails_closed(tmp_path: Path) -> None:
    import subprocess

    backend = PodmanBackend(config(tmp_path))
    watcher = subprocess.Popen((sys.executable, "-c", "pass"))
    watcher.wait(timeout=2)
    with pytest.raises(SandboxUnavailable, match="watchdog_exit"):
        backend._stop_watchdog(watcher)
    assert PodmanBackend(config(tmp_path)).probe().reason == "cleanup_unhealthy"
