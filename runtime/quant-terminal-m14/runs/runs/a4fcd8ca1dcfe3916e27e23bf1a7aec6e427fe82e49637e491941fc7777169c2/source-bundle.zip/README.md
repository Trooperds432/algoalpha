# Quantitative Research & Trading Terminal

Python-native, local-first quantitative research terminal for AlgoAlpha.

Current state: Milestones 0-13 have passed. The professional GUI (M14) is in
development. Production resource hardening (M15-16),
paper mode (M17), one broker architecture (M18), advanced risk/assets (M19-20), and
release hardening (M21) remain. No broker connection or order submission is enabled.

Start with [product requirements](docs/product_requirements.md),
[architecture](docs/system_architecture.md), [financial conventions](docs/backtesting_conventions.md)
and [roadmap](docs/roadmap.md). The full owner brief is preserved in
docs/sources/owner-brief.txt; extracted PDF context is in docs/sources/research-pdf.txt.

All 370 employees are mapped in coordination/agent-assignments.json. Their work is
staged by domain and milestone, with recorded evidence required for completion.
Later, agents will use the same terminal API/CLI as the human UI and record real
task outcomes. That interaction is an acceptance requirement; issue plans and
dispatches are not evidence of completed employee interaction.

For source-based M13 examples, see [headless usage](docs/headless-usage.md).
For the local interface, see [UI usage](docs/ui-usage.md).
