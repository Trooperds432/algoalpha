"""Headless research CLI; the GUI and HTTP adapter share its application service."""

from __future__ import annotations

import argparse
import json
import os
import sys
import time
from pathlib import Path
from typing import cast

from quant_terminal.application.jobs import KINDS, TERMINAL, JobManager, JobStore
from quant_terminal.application.service import ResearchService
from quant_terminal.core.exceptions import DomainError
from quant_terminal.experiments import canonical_json


def _request(path: str) -> dict[str, object]:
    raw = Path(path).read_bytes()
    if len(raw) > 10_000_000:
        raise DomainError("Request file exceeds 10 MB")
    payload = json.loads(raw)
    if not isinstance(payload, dict):
        raise DomainError("Expected a JSON request object")
    canonical_json(payload)
    return cast(dict[str, object], payload)


def parser() -> argparse.ArgumentParser:
    result = argparse.ArgumentParser(prog="quant", description="AlgoAlpha local research terminal")
    default_root = Path(os.environ.get("LOCALAPPDATA", str(Path.home()))) / "AlgoAlpha" / "research"
    result.add_argument("--state-dir", type=Path, default=default_root)
    result.add_argument("--project-root", type=Path, default=Path(__file__).resolve().parents[2])
    commands = result.add_subparsers(dest="command", required=True)
    for kind in sorted(KINDS):
        command = commands.add_parser(kind)
        command.add_argument("--request", required=True)
        command.add_argument("--timeout", type=int, default=300)
    importer = commands.add_parser("data-import")
    importer.add_argument("--request", required=True)
    report = commands.add_parser("report")
    report.add_argument("run_id")
    report.add_argument("--output", type=Path, required=True)
    compare = commands.add_parser("compare")
    compare.add_argument("run_ids", nargs="+")
    commands.add_parser("runs")
    commands.add_parser("strategies")
    commands.add_parser("datasets")
    job = commands.add_parser("job")
    job.add_argument("job_id")
    job.add_argument("--cancel", action="store_true")
    serve = commands.add_parser("serve")
    serve.add_argument("--port", type=int, default=8765)
    serve.add_argument("--workers", type=int, default=2)
    serve.add_argument("--timeout", type=int, default=300)
    return result


def main(argv: list[str] | None = None) -> int:
    args = parser().parse_args(argv)
    try:
        root, project = args.state_dir.resolve(), args.project_root.resolve()
        if args.command == "serve":
            import uvicorn

            from quant_terminal.api import create_app

            uvicorn.run(
                create_app(root, project, workers=args.workers, timeout=args.timeout),
                host="127.0.0.1",
                port=args.port,
            )
            return 0
        if args.command in KINDS:
            payload = _request(args.request)
            with JobManager(root, project, workers=1, timeout=args.timeout) as manager:
                job = manager.submit(args.command, payload)
                identity = str(job["id"])
                print(
                    canonical_json({"job_id": identity, "status": "queued"}).decode(),
                    file=sys.stderr,
                    flush=True,
                )
                while job["status"] not in TERMINAL:
                    if not manager.healthy:
                        raise DomainError("Research scheduler stopped unexpectedly")
                    time.sleep(0.1)
                    job = manager.store.get(identity)
            print(canonical_json(job).decode())
            return 0 if job["status"] == "succeeded" else 1
        value: object
        if args.command == "job":
            store = JobStore(root)
            value = store.cancel(args.job_id) if args.cancel else store.get(args.job_id)
        else:
            service = ResearchService(root, project)
            if args.command == "data-import":
                value = service.import_data(_request(args.request))
            elif args.command == "runs":
                value = service.runs()
            elif args.command == "strategies":
                value = service.runtime.strategies()
            elif args.command == "datasets":
                value = service.runtime.snapshots()
            elif args.command == "compare":
                value = service.compare(args.run_ids)
            else:
                # Exclusive creation prevents an accidental overwrite of a local report.
                with args.output.open("xb") as handle:
                    handle.write(service.html_report(args.run_id))
                value = {"run_id": args.run_id, "report": str(args.output.resolve())}
        print(canonical_json(value).decode())
        return 0
    except (DomainError, OSError, ValueError) as exc:
        print(
            canonical_json({"error": type(exc).__name__, "message": str(exc)}).decode(),
            file=sys.stderr,
        )
        return 1
    except KeyboardInterrupt:
        print('{"error":"Interrupted"}', file=sys.stderr)
        return 130


if __name__ == "__main__":
    raise SystemExit(main())
