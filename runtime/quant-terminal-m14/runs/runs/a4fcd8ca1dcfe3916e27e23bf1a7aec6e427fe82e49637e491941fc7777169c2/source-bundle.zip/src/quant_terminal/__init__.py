"""AlgoAlpha quantitative terminal: domain foundation."""

__version__ = "0.0.1"
